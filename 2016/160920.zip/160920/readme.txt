bad experiment

