  large clock offset  ??
error is dtau2.for, line 354
  




