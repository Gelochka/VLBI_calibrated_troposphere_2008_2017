  Large clock offset at Wettzell after the clock break
  




