no meteoparameters for Kunming and URUMQI 
Try to fix
  




